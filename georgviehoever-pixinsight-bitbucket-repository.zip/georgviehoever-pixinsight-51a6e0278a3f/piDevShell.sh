#!/bin/bash -x
#
# script for setting up a development environment for PCL development
piDefaultDir=$HOME/PixInsight
pclDefaultDir=$HOME/PCL

# if you need to use a different compiler, as I did due to a compilation issue:
# use gcc 4.6.3 instead of default gcc 4.7.2
# gccPath=$HOME/PCL_1.09/binutils/bin/bin

# print usage message and exit
usage () {
    echo "$(basename $0) [piDir [pclDir]]"
    echo "   set up environment variabels to support PCL development. Opens a shell with"
    echo "   environment variabels set as necessary. Leave the environment by"
    echo "   exiting from your shell."
    echo "Parameters:"
    echo "   piDir base directory of PixInsight installation. Defaults to \$HOME\PixInsight'."
    echo "   pclDir base directory of the PCL installation. Defaults to \$HOME/PCL."
    exit 1
}

# do plausibility check of paths
checkDirs () {
    if [ ! -f $pclDir/include/pcl/AbstractImage.h ]
    then
	echo "$pclDir apparently does not point to PCL installation"
	usage
    fi
    if [ ! -x $piDir/bin/PixInsight.sh ]
    then
	echo "$piDir apparently does not point to a PixInsight installation"
	usage
    fi
}

# extract base paths from arguments. return them in pclDir and piDir
extractBasePaths () {
    if [ $# -lt 1 ]
    then
	piDir=$piDefaultDir
    else
	piDir=$1
    fi
    if [ $# -lt 2 ]
    then
	pclDir=$pclDefaultDir
    else
	pclDir=$2
    fi
    # normalize paths
    piDir=$(realpath $piDir)
    pclDir=$(realpath $pclDir)
}

#
# main
#
extractBasePaths $*
checkDirs

# set environment variables for use with PCL
export PIDIR64=$piDir
export PIDIR32=. # modify as necessary, needs to point to existing directory
export PIDIR=$PIDIR64 # set to what is suitable for you

export PCLDIR=$pclDir
export PCLBINDIR64=$PCLDIR/bin 
export PCLBINDIR32=. # modify as necessary, needs to point to existing directory
export PCLBINDIR=$PCLBINDIR64 # set to what is suitable for you

export PCLLIBDIR64=$PCLDIR/lib/linux/x86_64
export PCLLIBDIR32=. # modify as necessary, needs to point to existing directory
export PCLLIBDIR=$PCLLIBDIR64 # set to what is suitable for you

export PCLINCDIR=$PCLDIR/include
export PCLSRCDIR=$PCLDIR/src

export PATH=$PIDIR/bin:$PATH
if [[ -n $gccPath ]]
then
    export PATH=$gccPath:$PATH
fi

echo "Starting new $SHELL with environment variables set up for PCL development"
exec $SHELL
