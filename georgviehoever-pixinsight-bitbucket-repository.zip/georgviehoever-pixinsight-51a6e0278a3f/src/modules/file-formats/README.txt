Directory for new file-format modules
