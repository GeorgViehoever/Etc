/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef __PythonParameters_h
#define __PythonParameters_h

#include <pcl/MetaParameter.h>

namespace pcl
{

PCL_BEGIN_LOCAL

/// boolean indicating if source should be read from file instead from entered text
class PythonParameter_UseSourceFile : public MetaBoolean
{
public:

   PythonParameter_UseSourceFile( MetaProcess* );
   virtual IsoString Id() const;
   virtual bool DefaultValue() const;
};
/// boolean indicating if source should be read from file instead from entered text
extern PythonParameter_UseSourceFile* ThePythonParameter_UseSourceFile;

/// Name of source file to use if ThePythonParameter_UseSourceFile==true
class PythonParameter_SourceFileName : public MetaString
{
public:
   PythonParameter_SourceFileName( MetaProcess* );
   virtual IsoString Id() const;
   virtual size_type MinLength() const;
   virtual String DefaultValue() const;
};
/// Name of source file to use if ThePythonParameter_UseSourceFile==true
extern PythonParameter_SourceFileName* ThePythonParameter_SourceFileName;

/// boolean indicating if Python interpreter should be reset before running
class PythonParameter_ResetBefore : public MetaBoolean
{
public:
   PythonParameter_ResetBefore( MetaProcess* );
   virtual IsoString Id() const;
   virtual bool DefaultValue() const;
};
/// boolean indicating if Python interpreter should be reset before running
extern PythonParameter_ResetBefore* ThePythonParameter_ResetBefore;

/// boolean indicating if Python interpreter should be reset after running
class PythonParameter_ResetAfter : public MetaBoolean
{
public:
   PythonParameter_ResetAfter( MetaProcess* );
   virtual IsoString Id() const;
   virtual bool DefaultValue() const;
};
/// boolean indicating if Python interpreter should be reset after running
extern PythonParameter_ResetAfter* ThePythonParameter_ResetAfter;

/// command line arguments appearing as sys::argv[] in Python
class PythonParameter_Args : public MetaString
{
public:
   PythonParameter_Args( MetaProcess* );
   virtual IsoString Id() const;
   virtual size_type MinLength() const;
};
/// command line arguments appearing as sys::argv[] in Python
extern PythonParameter_Args* ThePythonParameter_Args;

/// text of Python script interpreted if ThePythonParameter_UseSourceFile==false
class PythonParameter_Source : public MetaString
{
public:
   PythonParameter_Source( MetaProcess* );
   virtual IsoString Id() const;
   virtual size_type MinLength() const;
   virtual String DefaultValue() const;
};
/// text of Python script interpreted if ThePythonParameter_UseSourceFile==false
extern PythonParameter_Source* ThePythonParameter_Source;


PCL_END_LOCAL

} // pcl

#endif
