/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef __PythonModule_h
#define __PythonModule_h

#include <pcl/MetaModule.h>

namespace pcl
{


class PythonModule : public MetaModule
{
public:

   PythonModule();

   virtual const char* Version() const;
   virtual IsoString Name() const;
   virtual String Description() const;
   virtual String Company() const;
   virtual String Author() const;
   virtual String Copyright() const;
   virtual String TradeMarks() const;
   virtual String OriginalFileName() const;
   virtual void GetReleaseDate( int& year, int& month, int& day ) const;
};

// ----------------------------------------------------------------------------

} // pcl

#endif


