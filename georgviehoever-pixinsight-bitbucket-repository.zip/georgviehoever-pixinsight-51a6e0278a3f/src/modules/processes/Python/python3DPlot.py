#!/usr/bin/env python2.7
""" Script for plotting interactive profile
"""

from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FixedLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import numpy as np
import pixinsight_api as pi

def execute_on(view):
    """ interactive 3D profile of luminance data in view
    
    Note: In contrast to the 3DPlot.js script we do not apply the STF
    """
    #import datetime
    image=view.image
    width=image.width
    height=image.height
    if width>128 or height>128:
        raise ValueError("height or width too large")
    lumImage=image.get_luminance().get_channel_as_list(0)
    title="Luminance Profile"
    Z=np.array(lumImage)
    
    fig = plt.figure()
    zmax=Z.max()
    zmin=Z.min()
    ax = fig.gca(projection='3d')
    ax.set_title(title)
    X = np.arange(0,width, 1)
    Y = np.arange(0,height, 1)
    X, Y = np.meshgrid(X, Y)
    surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, alpha=0.3,
        linewidth=0, antialiased=False)
    cset = ax.contour(X, Y, Z, zdir='z', offset=0)
    cset = ax.contour(X, Y, Z, zdir='x', offset=width)
    cset = ax.contour(X, Y, Z, zdir='y', offset=height)
    ax.set_zlim3d(zmin, zmax)
    ax.w_zaxis.set_major_locator(LinearLocator(10))
    ax.w_zaxis.set_major_formatter(FormatStrFormatter('%.03g'))

    plt.show()
    return True;

if __name__=="__main__":
    print "Profile function loaded"
    
    
    
