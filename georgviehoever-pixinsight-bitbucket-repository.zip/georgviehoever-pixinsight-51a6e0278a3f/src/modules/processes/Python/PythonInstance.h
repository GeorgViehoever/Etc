/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef __PythonInstance_h
#define __PythonInstance_h


#include <pcl/ProcessImplementation.h>
#include <pcl/MetaParameter.h> // for pcl_bool, pcl_enum

#include <string>
#include <vector>

namespace pcl
{

// ----------------------------------------------------------------------------
// PythonInstance
// ----------------------------------------------------------------------------

class PythonInstance : public ProcessImplementation
{
public:

   PythonInstance( const MetaProcess* );
   PythonInstance( const PythonInstance& );

   virtual void Assign( const ProcessImplementation& );

   /// checks if there is valid script
   virtual bool CanExecuteGlobal(pcl::String& whyNot) const;
   /// checks if there is valid script
   virtual bool CanExecuteOn( const View&, pcl::String& whyNot ) const;

   virtual bool ExecuteGlobal();
   virtual bool ExecuteOn( View& );

   virtual void* LockParameter( const MetaParameter*, size_type tableRow );
   virtual bool AllocateParameter( size_type sizeOrLength, const MetaParameter* p, size_type tableRow );
   virtual size_type ParameterLength( const MetaParameter* p, size_type tableRow ) const;


   /// run Idle GUI. if bUseSourceFile, open with given file name
   void runIdle();

   /// run Spyder GUI
   void runSpyder();

private:

   // types

   /// string vector
   typedef std::vector<std::string> StringVec_t;

   // methods

   /// do global execute in static environment. Used by ExecuteGlobal() / ExecuteLocal()
   ///
   /// First compiles and executes source code, indicating it is the _main_ module.
   /// Then, if bRunMethod=true, call python execute_global() or execute_on(*pView_p)
   ///
   /// @note the calls used here capture all exceptions *except* SystemExit (raised by sys.exit()).
   /// I think that is ok because if the user wants the system to exit, it is just what should happen.
   /// It is still possible to capture this Exception from within Python to avoid this behaviour.
   ///
   /// @param bResetBefore_p reset interpreter before running
   /// @param bResetAfter_p reset interpreter after running
   /// @param bUseSourceFile_p use rsFileName_p as name of file containing code
   /// @param rsFileName_p if bUseSourceFile_p: name of source file. Otherwise ignored
   /// @param rsSource_p if not bUseSourceFile_p: code to be executed
   /// @param rArgv vector of arguments going into sys.argv
   /// @param bRunMethod if true, call ExecuteGlobal() or ExecuteOn(*pView_p) after interpreting the source code
   /// @param bRunExecuteGlobal if true, call execute_global(), else call execute_on(view)
   /// @param pView_p view for execute_on()
   ///
   /// @returns true if successful, or false or throws if not successful. rPyCompilerFlags is updated
   static bool staticExecuteGlobal(bool bResetBefore_p, bool bResetAfter_p,bool bUseSourceFile_p,
    		std::string const &rsFileName_p, std::string const &rsSource_p, StringVec_t const & rArgv,
    		bool bRunMethod_p=false,bool bRunExecuteGlobal_p=true, View *pView_p=NULL);

   /// return string used to start up Idle shell
   std::string const & getIdleString() const;

   /// return string for startup of Spyder shell
   std::string const & getSpyderString() const;

   /// run IDE defined by string, with argv as command line vector
   void runIde(std::string const &rsIdeString_p, StringVec_t const &rArgv_p);

   /// split sArgs into separate arguments and return them
   StringVec_t getArgv() const;

   // member variables

   /// true if we ought to use source file instead of source text
   pcl_bool bUseSourceFile;
   /// name of source file if bUseSourceFile==true
   String sSourceFileName;
   /// true if reset before interpreter run
   pcl_bool bResetBefore; 
   /// true if reset after interpreter run
   pcl_bool bResetAfter;
   /// arguments string, appears as sys.argv in interpreter
   String sArgs;
   /// source of script if bUseSourceFile==false
   String sSource;

   friend class PythonEngine;
   friend class PythonProcess;
   friend class PythonInterface;
};

// ----------------------------------------------------------------------------


} // pcl

#endif
