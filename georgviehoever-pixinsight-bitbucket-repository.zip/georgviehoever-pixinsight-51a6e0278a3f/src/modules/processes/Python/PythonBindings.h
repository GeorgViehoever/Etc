/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef __PythonBindings_h
#define __PythonBindings_h


/// if necessary, initialize the Python compiler (Py_Initialize()).
///
/// If it initializes, it also calls pyInitializeConverters()
/// and initializes the pixinsight bindings
extern "C" void pyInitialize();
#endif
