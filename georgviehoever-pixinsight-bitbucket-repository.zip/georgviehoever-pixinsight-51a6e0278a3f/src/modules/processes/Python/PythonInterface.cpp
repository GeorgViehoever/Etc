/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include <pcl/FileDialog.h>
#include "PythonInterface.h"
#include "PythonProcess.h"
#include "PythonParameters.h"

namespace pcl
{

// ----------------------------------------------------------------------------

PythonInterface* ThePythonInterface = 0;

// ----------------------------------------------------------------------------

//#include "PythonIcon.xpm"

// ----------------------------------------------------------------------------

PythonInterface::PythonInterface() :
ProcessInterface(), instance( ThePythonProcess ), GUI( 0 )
{
   ThePythonInterface = this;
}

PythonInterface::~PythonInterface()
{
   if ( GUI != 0 )
      delete GUI, GUI = 0;
}

IsoString PythonInterface::Id() const
{
   return "Python";
}

MetaProcess* PythonInterface::Process() const
{
   return ThePythonProcess;
}

const char** PythonInterface::IconImageXPM() const
{
   return 0; // PythonIcon_XPM; ---> put a nice icon here
}

InterfaceFeatures PythonInterface::Features() const
{
	return InterfaceFeature::DefaultGlobal|InterfaceFeature::Default;
}

void PythonInterface::ApplyInstance() const
{
   instance.LaunchOnCurrentView();
}

void PythonInterface::ResetInstance()
{
   PythonInstance defaultInstance( ThePythonProcess );
   ImportProcess( defaultInstance );
}

bool PythonInterface::Launch( const MetaProcess& P, const ProcessImplementation*, bool& dynamic, unsigned& /*flags*/ )
{
   // ### Deferred initialization
   if ( GUI == 0 )
   {
      GUI = new GUIData( *this );
      SetWindowTitle( "Python" );
      UpdateControls();
   }

   dynamic = false;
   return &P == ThePythonProcess;
}

ProcessImplementation* PythonInterface::NewProcess() const
{
   return new PythonInstance( instance );
}

bool PythonInterface::ValidateProcess( const ProcessImplementation& p, String& whyNot ) const
{
   const PythonInstance* r = dynamic_cast<const PythonInstance*>( &p );
   if ( r == 0 )
   {
      whyNot = "Not a Python instance.";
      return false;
   }

   whyNot.Clear();
   return true;
}

bool PythonInterface::RequiresInstanceValidation() const
{
   return true;
}

bool PythonInterface::ImportProcess( const ProcessImplementation& p )
{
   instance.Assign( p );
   UpdateControls();
   return true;
}

// ----------------------------------------------------------------------------

void PythonInterface::UpdateControls()
{
	GUI->InputFile_CheckBox.SetChecked(instance.bUseSourceFile);
	GUI->InputFile_Edit.SetText(instance.sSourceFileName);
	//std::cout<<"Set InputFileEdit text="<<instance.sSourceFileName<<std::endl;
	GUI->ResetBefore_CheckBox.SetChecked(instance.bResetBefore);
	GUI->ResetAfter_CheckBox.SetChecked(instance.bResetAfter);
	GUI->Args_Edit.SetText(instance.sArgs);
	GUI->Source_TextBox.SetText(instance.sSource);

	GUI->InputFile_Edit.Enable(instance.bUseSourceFile);
	GUI->InputFile_ToolButton.Enable(instance.bUseSourceFile);
	GUI->Source_TextBox.Disable(instance.bUseSourceFile);

}

// ----------------------------------------------------------------------------

void PythonInterface::__IdleButton_Pressed( PushButton& sender )
{
   if ( sender == GUI->Idle_PushButton )
   {
	   //std::cout<<"Idle Button Pressed"<<std::endl;
	   Disable();
	   ProcessEvents();
	   instance.runIdle();
	   Enable();
   }
}

void PythonInterface::__SpyderButton_Pressed( PushButton& sender )
{
   if ( sender == GUI->Spyder_PushButton )
   {
	   //std::cout<<"Spyder Button Pressed"<<std::endl;
	   Disable();
	   ProcessEvents();
	   instance.runSpyder();
	   Enable();
   }
}

void PythonInterface::__InputFileCheckBox_Clicked( Button& sender, bool checked )
{
   if ( sender == GUI->InputFile_CheckBox ){
	   instance.bUseSourceFile=checked;
	   UpdateControls();
   }
}

void PythonInterface::__InputFileEdit_Completed( Edit& sender )
{
   if ( sender == GUI->InputFile_Edit ){
	   String text = sender.Text().Trimmed();
	   instance.sSourceFileName=text;
	   UpdateControls();
   }
}

void PythonInterface::__InputFileToolButton_Clicked( Button& sender, bool checked )
{
   if ( sender == GUI->InputFile_ToolButton )
   {
      OpenFileDialog d;
      d.SetCaption( "Python: Select a source file" );
      // FIXME currently does not filter for *.py files
      d.SetSelectedFileExtension("*.py");
      if ( d.Execute() ){
    	  String text = d.FileName().Trimmed();
    	  //std::cout<<"InputFile selected="<<text<<std::endl;
    	  instance.sSourceFileName=text;
    	  UpdateControls();
        }
   }
}

void PythonInterface::__ResetBeforeCheckBox_Clicked( Button& sender, bool checked )
{
   if ( sender == GUI->ResetBefore_CheckBox )
	   instance.bResetBefore=checked;
}


void PythonInterface::__ResetAfterCheckBox_Clicked( Button& sender, bool checked )
{
   if ( sender == GUI->ResetAfter_CheckBox )
	   instance.bResetAfter=checked;
}

void PythonInterface::__Args_EditCompleted( Edit& sender )
{
   if ( sender == GUI->Args_Edit ){
	   instance.sArgs=sender.Text();
   }
}

void PythonInterface::__Source_LoseFocus( Control &sender)
{
	if ( sender== GUI->Source_TextBox){
#ifdef USE_CODE_EDITOR
		CodeEditor &textBox=dynamic_cast<CodeEditor &>(sender);
#else
		TextBox &textBox=dynamic_cast<TextBox&>(sender);
#endif
		instance.sSource=textBox.Text();
	}
}




// ----------------------------------------------------------------------------

PythonInterface::GUIData::GUIData( PythonInterface& w )
{
   pcl::Font fnt = w.Font();
   int labelWidth1 = fnt.Width( String( "Arguments:" ) ); // the longest label text
   int editWidth1 = fnt.Width( String( '0', 7 ) );

   IDE_Label.SetText( "IDE:" );
   IDE_Label.SetFixedWidth( labelWidth1 );
   IDE_Label.SetTextAlignment( TextAlign::Right|TextAlign::VertCenter );
   IDE_Label.SetToolTip( "Open an IDE" );
   Idle_PushButton.SetText("IDLE");
   Idle_PushButton.SetToolTip("Launches the Python IDLE shell");
   Idle_PushButton.OnPress(reinterpret_cast<Button::press_event_handler>(&PythonInterface::__IdleButton_Pressed),w);
   // FIXME Spyder disabled for the moment, does not work, most likely due to Qt version conflicts
   //Spyder_PushButton.SetText("Spyder");
   //Spyder_PushButton.SetToolTip("Launches the Python Spyder Development IDE");
   //Spyder_PushButton.OnPress(reinterpret_cast<Button::press_event_handler>(&PythonInterface::__SpyderButton_Pressed),w);
   ShellButtons_Sizer.SetSpacing( 4 );
   ShellButtons_Sizer.Add( IDE_Label );
   ShellButtons_Sizer.Add( Idle_PushButton );
   // FIXME Spyder disabled for the moment
   //ShellButtons_Sizer.Add( Spyder_PushButton );
   ShellButtons_Sizer.AddStretch();

   const char* inputFileToolTip = "<p>File from which Python source is read.</p>";

   InputFile_CheckBox.SetText( "Use File:" );
   InputFile_CheckBox.SetToolTip( "<p>Check to read source from file instead of text field below</p>" );
   InputFile_CheckBox.OnClick( (pcl::Button::click_event_handler)&PythonInterface::__InputFileCheckBox_Clicked, w );

   InputFile_Edit.SetToolTip( inputFileToolTip );
   InputFile_Edit.OnEditCompleted( (Edit::edit_event_handler)&PythonInterface::__InputFileEdit_Completed, w );

   InputFile_ToolButton.SetIcon( Bitmap( String( ":/images/icons/select.png" ) ) );
   InputFile_ToolButton.SetFixedSize( 19, 19 );
   InputFile_ToolButton.SetToolTip( "<p>Select a file containing Python source</p>" );
   InputFile_ToolButton.OnClick( (Button::click_event_handler)&PythonInterface::__InputFileToolButton_Clicked, w );

   InputFile_Sizer.SetSpacing( 4 );
   InputFile_Sizer.Add( InputFile_CheckBox );
   InputFile_Sizer.Add( InputFile_Edit, 100 );
   InputFile_Sizer.Add( InputFile_ToolButton );

   // FIXME maybe remove the reset check boxes...
   ResetBefore_CheckBox.SetText( "Reset Before" );
   ResetBefore_CheckBox.SetToolTip( "<p>Reset Python environment before running.</p>" );
   ResetBefore_CheckBox.OnClick( (pcl::Button::click_event_handler)&PythonInterface::__ResetBeforeCheckBox_Clicked, w );
   ResetAfter_CheckBox.SetText( "Reset After" );
   ResetAfter_CheckBox.SetToolTip( "<p>Reset Python environment after running.</p>" );
   ResetAfter_CheckBox.OnClick( (pcl::Button::click_event_handler)&PythonInterface::__ResetAfterCheckBox_Clicked, w );

   Reset_Sizer.SetSpacing(4 );
   Reset_Sizer.Add( ResetBefore_CheckBox );
   Reset_Sizer.Add( ResetAfter_CheckBox );
   Reset_Sizer.AddStretch();

   Args_Label.SetText( "Arguments:" );
   Args_Label.SetMinWidth( labelWidth1 );
   Args_Label.SetToolTip( "<p>Blank separated arguments to the executed source. Access as sys.argv[].</p>" );
   Args_Label.SetTextAlignment( TextAlign::Right|TextAlign::VertCenter );
   Args_Edit.SetMinWidth( editWidth1 );
   Args_Edit.SetToolTip( "<p>Blank separated arguments to the executed source. Access as sys.argv[].</p>" );
   Args_Edit.OnEditCompleted( reinterpret_cast<Edit::edit_event_handler>(&PythonInterface::__Args_EditCompleted), w );
   Args_Sizer.SetSpacing( 4 );
   Args_Sizer.Add( Args_Label );
   Args_Sizer.Add( Args_Edit, 100 );

   Source_TextBox.SetText( "TestText" );
   Source_TextBox.OnLoseFocus( reinterpret_cast<Control::event_handler>(&PythonInterface::__Source_LoseFocus), w );
   Source_TextBox.SetToolTip("<p>Source to be executed</p>");
   //Source_Sizer.SetMargin( 6 );
#ifdef USE_CODE_EDITOR
   Source_TextBox.SetFilePath("script.py");
   Source_Sizer.Add( Source_TextBox.LineNumbersControl());
#endif
   Source_Sizer.Add( Source_TextBox );

   //

   Global_Sizer.SetMargin( 8 );
   Global_Sizer.SetSpacing( 6 );
   Global_Sizer.Add( ShellButtons_Sizer );
   Global_Sizer.Add( InputFile_Sizer );
   // FIXME currently deactivated to to issues with Py_Finalize()
   //Global_Sizer.Add( Reset_Sizer );
   Global_Sizer.Add( Args_Sizer);
   Global_Sizer.Add( Source_Sizer);

   w.SetSizer( Global_Sizer );
   w.AdjustToContents();
   //w.SetFixedSize();
}

// ----------------------------------------------------------------------------

} // pcl

