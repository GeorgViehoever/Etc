/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "PythonBindings.h"

#include <boost/python.hpp>

#include <pcl/Console.h>
#include <pcl/ImageWindow.h>
#include <pcl/View.h>
#include <pcl/ImageVariant.h>
#include <pcl/Exception.h>
#include <pcl/String.h>

using namespace pcl;


namespace {
// anonymous namespace to avoid cluttering symbol space

//
// Language Bindings using Boost::Python
//
// I am using Boost Python here because many of the alternatives (swig, shiboken, sep, ackward, ..) try to convert from C(++) headers to
// Python bindings. I think this approach is wrong, because this ignores the pythonic way of doing things.
// The goal of the bindings provided here is to give a minimal interface that enables work of PI with Python.
// This currently means that
// - for GUI, there will be no bindings. The intention is to use the available Python GUIs (e.g. tk)
// - there is no templated image object (or several objects with different pixel types). Instead, there
//   is only one image type for everything
// - mapping to suitable Python types happens wherever possible (e.g. pcl::String to str/unicode, pcl StringList to list of strings,...
//
// Note: This is work in progress.
//
// Literature:
// "Extending and Embedding the Python Interpreter", Python Documentation: http://docs.python.org/2/extending/
// "Python/C API Reference", Python Documentation: http://docs.python.org/2/c-api/
//  "Boost Python Documentation": http://www.boost.org/doc/libs/1_5w_0/libs/python/doc/
//  "Timothy Shead: Extreme Object Models Using Boost.Python" (Presentation at Boost Con 2007):
//    https://github.com/boostcon/2007_presentations/raw/master/Extreme_Object_Models_Using_Boost.Python.pdf
//  "How to write boost.python converters": http://misspent.wordpress.com/2009/09/27/how-to-write-boost-python-converters/
/// Boost::Python wiki: http://wiki.python.org/moin/boost.python

// PCL Mapping:
// Console, to be able to output text
// ImageWindow
// View
// Image

using namespace boost::python;

//Note: Use of those BOOST_PYTHON_*_FUNCTION_OVERLOAD macros needs to happen outside BOOST_PYTHON_MODULE


// using dispatch method "borrowed" from PCL2.0:
/// dispatch depending on type of ImageVariant in self. F is expected to be a macro that
/// expects the concrete GenericImage2D<> type as argument.
#define PYTHON_SOLVE_TEMPLATE( F )         \
if ( self.IsComplexSample() )                   \
	switch ( self.BitsPerSample() )             \
	{                                      \
		case 32: F( ComplexImage ); break; \
		case 64: F( DComplexImage ); break;\
    }                                      \
else if ( self.IsFloatSample() )                \
    switch ( self.BitsPerSample() )             \
    {                                      \
        case 32: F( Image ); break;        \
        case 64: F( DImage ); break;       \
    }                                      \
else                                       \
    switch ( self.BitsPerSample() )             \
   {                                       \
        case  8: F( UInt8Image ); break;   \
        case 16: F( UInt16Image ); break;  \
        case 32: F( UInt32Image ); break;  \
   }

//
// functions for Console
//
//

/// for print output by write method
static void console_write_raw(Console &self, const char * string)
{
	self.Write(String().Format("<raw>%s</raw>",string));
}

//
// methods for ImageWindow
//
BOOST_PYTHON_FUNCTION_OVERLOADS(imagewindow_open_overloads,ImageWindow::Open,1,4)

//
// methods for View
//

// Using overloads to allow methods with default args
BOOST_PYTHON_FUNCTION_OVERLOADS(view_all_views_overloads,View::AllViews,0,1)
BOOST_PYTHON_MEMBER_FUNCTION_OVERLOADS(view_lock_overloads,View::Lock,0,1)
BOOST_PYTHON_MEMBER_FUNCTION_OVERLOADS(view_lock_for_write_overloads,View::LockForWrite,0,1)
BOOST_PYTHON_MEMBER_FUNCTION_OVERLOADS(view_relock_for_read_overloads,View::RelockForRead,0,1)
BOOST_PYTHON_MEMBER_FUNCTION_OVERLOADS(view_unlock_overloads,View::Unlock,0,1)
BOOST_PYTHON_MEMBER_FUNCTION_OVERLOADS(view_unlock_for_read_overloads,View::UnlockForRead,0,1)

/// return None if view does not exist, otherwise the View
static object view_view_by_id(const IsoString &  fullId)
{
	View view=View::ViewById(fullId);
	if(view.IsNull()){
		return object();
	}else {
		return object(view);
	}
}

/// for __str__
static String view_str(View const & self)
{
	return String().Format("View(id=%s)",self.FullId().c_str());
}

//
// Methods for ImageVariant
//
/// for _str_
static String imagevariant_str(ImageVariant const & self)
{
	std::string type("undefined");
#define _IMAGE_VARIANT_GET_TYPE(I) type=#I
	PYTHON_SOLVE_TEMPLATE(_IMAGE_VARIANT_GET_TYPE)
#undef _IMAGE_VARIANT_GET_TYPE
	return String().Format("Image(w=%d,h=%d,nChan=%d,type=%s)@%x",self.Width(),self.Height(),
			self.NumberOfChannels(),type.c_str(),self.AnyImage());
}

/// convert rImage to 2d list
template <class ImageType>
static list imagevariant_channelToList(ImageType const & rImage_p,int channel)
{
	if (channel>=rImage_p.NumberOfChannels())
	{
		throw Error("Trying to access non-existing channel");
	}
	std::size_t const nRows=rImage_p.Height();
	std::size_t const nCols=rImage_p.Width();
	list resList;
	for(std::size_t row=0;row<nRows;++row)
	{
		list listRow;
		for(std::size_t col=0;col<nCols;++col)
		{
			typename ImageType::sample const sample= rImage_p.Pixel(col,row,channel);
			listRow.append(sample);
		}
		resList.append(listRow);
	}
	return resList;
}


/// return the content of the given channel as a 2d list
// FIXME need to support array or numpy.ndarray here
static list imagevariant_get_channel_as_list(ImageVariant const & self,int channel)
{
#define _CHANNEL_AS_LIST( I ) \
 res=imagevariant_channelToList(static_cast<const pcl::I&>( *self ),channel)

	list res;
	PYTHON_SOLVE_TEMPLATE(_CHANNEL_AS_LIST)
	return res;
#undef _CHANNEL_AS_LIST
}

/// get all channels of image as list of 2D lists as generated by get_channel_as_list()
static list imagevariant_get_image_as_list(ImageVariant const & self)
{
	list res;
	for(int i=0;i<self.NumberOfChannels();++i){
		list channel=imagevariant_get_channel_as_list(self,i);
		res.append(channel);
	}
	return res;
}

/// get the luminance of self. Note that ownership of the returned pointer is with the caller
ImageVariant * imagevariant_get_luminance(ImageVariant const & self)
{

	ImageVariant &res= *new ImageVariant();
	self.GetLuminance(res);
	return &res;
}

/// method to translate PCL::Exception into message for Boost::Python
void translate_pcl_exception(const Exception &e)
{
	PyErr_SetString(PyExc_Exception, IsoString(e.Message()).c_str());
}

/// needed for output redirection
static object consoleClass;

BOOST_PYTHON_MODULE(pixinsight_api)
{
	// translation for PCL Exceptions
	register_exception_translator<Exception>(&translate_pcl_exception);

	// Wrapping Console, providing the minimum necessary for writing messages
	// resolve overloading in WriteLn
	void (Console::*console_writeLn0)()= &Console::WriteLn;
	void (Console::*console_writeLn1)(const String &)=&Console::WriteLn;

	consoleClass=class_<Console>("Console",
			"represent the PCL::Console() class. See write(),write_tagged() for deviations from original.")
					// Abort()
					// AbortEnabled()
					.def("clear",&Console::Clear)
					// DisableAbort()
					// EnableAbort()
					.def("flush",&Console::Flush)
					.def("hide",&Console::Hide)
					//.def("is_current_thread_console",&Console::IsCurrentThreadConsole)
					.def("is_valid",&Console::IsValid)
					// ReadChar()
					// ReadString()
					// ResetStatus()
					.def("show",&Console::Show)
					// Suspended()
					// Waiting()
					// without interpretation of tags. Required for print, otherwise
					// output like <type> is hidden
					.def("write",console_write_raw,"outputs without interpretation of tags, except </raw>. Also used for Python print output")
					// with interpretation of tags
					.def("writeTagged",&Console::Write,"output with interpretation of tags. See also write() and writeln()")
					.def("writeln",console_writeLn1)
					.def("writeln",console_writeLn0)
					;

	class_<ImageWindow>("ImageWindow",
			"represents PCL::ImageWindow class. Currently very basic...",
			init<const ImageWindow &>())
					// FIXME define reasonable constructors
					// FIXME some __str__ method
					// not giving ownership to python because ImageWindows are generally managed by PCL
					.def("window_by_file_path",&ImageWindow::WindowByFilePath)
					.staticmethod("window_by_file_path")
					// Note: cannot be constructor because it returns list of ImageWindows
					.def("open",&ImageWindow::Open,imagewindow_open_overloads())
					.staticmethod("open")
					.add_property("current_view",&ImageWindow::CurrentView)
					.add_property("main_view",&ImageWindow::MainView)
					.def("show",&ImageWindow::Show)
					;

	// select one of the templates of this method
	bool (*View_IsValidViewIDIsoString)(const IsoString &)= &View::IsValidViewId;

	// Wrapping views, with the goal to get access to image
	class_<View>("View",
			"represents PCL::View class. See view_by_id() for deviation from original class.",
			no_init)
					// Views are no_init, because they are always created as part of an ImageWindow
					// for output in python
					// def(self_ns::str(self))
					.def("_str_",&view_str)
					// AddToDynamicTargets ()
					// AreHistogramsAvailable () const
					// AreScreenTransferFunctionsEnabled () const
					// AreStatisticsAvailable () const
					// Rect Bounds () const
					// void CalculateHistograms (bool notify=true)
					//void CalculateStatistics (bool notify=true)
					.add_property("can_read",&View::CanRead)
					.add_property("can_write",&View::CanWrite)
					// void	DestroyHistograms (bool notify=true)
					// void DestroyScreenTransferFunctions (bool notify=true)
					// void DestroyStatistics (bool notify=true)
					// void DisableScreenTransferFunctions (bool disable=true, bool notify=true)
					// void	EnableScreenTransferFunctions (bool=true, bool notify=true)
					.add_property("full_id",&View::FullId)
					// void GetHistograms (histogram_list &) const
					// ImageVariant GetImage () const
					.add_property("image",&View::GetImage)
					// void GetScreenTransferFunctions (stf_list &) const
					// void GetSize (int &width, int &height) const
					// void GetStatistics (statistics_list &) const
					.add_property("height",&View::Height)
					.add_property("id",&View::Id)
					// ImageVariant Image () const
					.add_property("is_color",&View::IsColor)
					.add_property("is_dynamic_target",&View::IsDynamicTarget)
					.add_property("is_main_view",&View::IsMainView)
					.add_property("is_preview",&View::IsPreview)
					.def("lock",&View::Lock,view_lock_overloads(args("notify")))
					.def("lock_for_write",&View::LockForWrite,view_lock_for_write_overloads(args("notify")))
					.def("relock_for_read",&View::RelockForRead,view_relock_for_read_overloads(args("notify")))
					// void RemoveFromDynamicTargets ()
					.def("rename",&View::Rename)
					// void SetScreenTransferFunctions (const stf_list &, bool notify=true)
					.def("unlock",&View::Unlock,view_unlock_overloads(args("notify")))
					.def("unlock_for_read",&View::UnlockForRead,view_unlock_for_read_overloads(args("notify")))
					.add_property("width",&View::Width)
					//
					// static methods
					//
					// ImageWindow Window () const
					.def("all_previews",View::AllPreviews)
					.staticmethod("all_previews")
					.def("all_views",View::AllViews,view_all_views_overloads(args("excludePreviews")))
					.staticmethod("all_views")
					// template<typename S > static bool IsValidViewId (const S &id)
					.def("is_valid_view_id",View_IsValidViewIDIsoString)
					.staticmethod("is_valid_view_id")
					// Queries about valid are not necessary because view are None if not valid
					//.def("null",View::Null)
					//.staticmethod("null")
					// static View & Null ()
					//.def("view_by_id",&View::ViewById)
					.def("view_by_id",view_view_by_id,"like C++ counterpart, only returns None if view does not exist")
					.staticmethod("view_by_id")
					;

	// FIXME we may need constructors for GenericImages here. For the moment, we
	// only allow Images that are generated by the PI core ("shared" images)
	class_<ImageVariant>("Image",
			"represents all types of PCL::GenericImage<type>. Similar to PCL::ImageVariant.",
			no_init)
					// for default output on Python.
					// See http://mail.python.org/pipermail/cplusplus-sig/2005-February/008295.html for use of self_ns
					//.def(self_ns::str(self))
					.def("_str_",&imagevariant_str)
					// ImageVariant ()
					// template<class P > ImageVariant (Generic2DImage< P > *image)
					// ImageVariant (const ImageVariant &v)
					// virtual ~ImageVariant ()
					.def("get_channel_as_list",&imagevariant_get_channel_as_list,
							"Gets specified channel as [[row0,[row1],...]. Channel number includes possible alpha channel")
					.def("get_image_as_list",&imagevariant_get_image_as_list,
									"Get all channels as [channel0,channel1], with each channel as in get_channel_as_list()")
					// note: this is already the PCL2.0 interface.
					// note: Python needs to manage this object, it is not a PI core one.
					.def("get_luminance",&imagevariant_get_luminance,
									return_value_policy<manage_new_object>(),
									"returns the luminance of this image in PCL2.0 sense")
					// void AllocateImage (int width, int height, int numberOfChannels, color_space colorSpace)
					// const AbstractImage * AnyImage () const
					// AbstractImage * AnyImage ()
					// void Assign (const ImageVariant &v)
					// int BitsPerSample () const
					.add_property("bits_per_sample",&ImageVariant::BitsPerSample)
					// int BytesPerSample () const
					.add_property("bytes_per_sample",&ImageVariant::BytesPerSample)
					// String ChannelId (int c) const
					.add_property("channel_id",&ImageVariant::ChannelId)
					// color_space ColorSpace () const
					// template<class I > void CopyImage (const I &image)
					// void CopyImage (const ImageVariant &v)
					// void CreateComplexImage (int n=32)
					// void CreateFloatImage (int n=32)
					// void CreateImage (bool isFloat, bool isComplex, int n)
					// void CreateImage ()
					// template<class P > void CreateImageAs (const pcl::Generic2DImage< P > &image)
					// void CreateImageAs (const ImageVariant &v)
					// void CreateSharedComplexImage (int n=32)
					// void CreateSharedFloatImage (int n=32)
					// void CreateSharedImage (bool isFloat, bool isComplex, int n)
					// void CreateSharedImage ()
					// template<class P > void CreateSharedImageAs (const pcl::Generic2DImage< P > &image)
					// void CreateSharedImageAs (const ImageVariant &v)
					// void CreateSharedUIntImage (int n=16)
					// void CreateUIntImage (int n=16)
					// void Free ()
					// void FreeImage ()
					// bool HasAlphaChannels () const
					// int Height () const
					.add_property("height",&ImageVariant::Height)
					// size_type ImageSize () const
					.add_property("image_size",&ImageVariant::ImageSize)
					// template<class P > bool IsAs (const pcl::Generic2DImage< P > &) const
					// bool IsColor () const
					.add_property("is_color",&ImageVariant::IsColor)
					// bool IsComplexSample () const
					.add_property("is_complex_sample",&ImageVariant::IsComplexSample)
					// bool IsFloatSample () const
					.add_property("is_float_sample",&ImageVariant::IsFloatSample)
					// bool IsImage () const
					.add_property("is_image",&ImageVariant::IsImage)
					// bool IsSameImage (const ImageVariant &v) const
					// void MaskFromSwapFile (const String &filePath, const ImageVariant &mask, bool invert=false)
					// void MaskFromSwapFiles (const String &fileName, const StringList &directories, const ImageVariant &mask, bool invert=false)
					// void MaskImage (const ImageVariant &src, const ImageVariant &mask, bool invert=false)
					// int NumberOfAlphaChannels () const
					.add_property("number_of_alpha_channels",&ImageVariant::NumberOfAlphaChannels)
					// size_type NumberOfAlphaSamples () const
					.add_property("number_of_alpha_samples",&ImageVariant::NumberOfAlphaSamples)
					// int NumberOfChannels () const
					.add_property("number_of_channels",&ImageVariant::NumberOfChannels)
					// int NumberOfNominalChannels () const
					.add_property("number_of_nominal_channels",&ImageVariant::NumberOfNominalChannels)
					// size_type NumberOfNominalSamples () const
					.add_property("number_of_nominal_samples",&ImageVariant::NumberOfNominalSamples)
					// size_type NumberOfPixels () const
					.add_property("number_of_pixels",&ImageVariant::NumberOfPixels)
					// size_type NumberOfSamples () const
					.add_property("number_of_samples",&ImageVariant::NumberOfSamples)
					// const AbstractImage & operator* () const
					// AbstractImage & operator* ()
					// const AbstractImage *
					// operator-> () const
					// AbstractImage * operator-> ()
					// ImageVariant & operator= (const ImageVariant &v)
					// bool OwnsImage () const
					// void ReadSwapFile (const String &filePath)
					// void ReadSwapFiles (const String &fileName, const StringList &directories)
					// const RGBColorSystem & RGBWorkingSpace () const
					// template<class P > void SetImage (Generic2DImage< P > &image)
					// void SetOwnership (bool owner=true)
					// void SetRGBWorkingSpace (const RGBColorSystem &rgbws)
					// void SetStatusCallback (pcl::StatusCallback *callback) const
					// StatusMonitor & Status () const
					// pcl::StatusCallback * StatusCallback () const
					// void Swap (ImageVariant &v)
					// void TransferTo (ImageVariant &v)
					// int Width () const
					.add_property("width",&ImageVariant::Width)
					// void WriteSwapFile (const String &filePath) const
					// void WriteSwapFiles (const String &fileName, const StringList &directories) const
					//
					// Static Public Member Functions
					//
					// static void DeleteSwapFile (const String &filePath)
					// static void DeleteSwapFiles (const String &fileName, const StringList &directories)
					// static uint64 SwapFileSize (const String &filePath)
					// static uint64 SwapFilesSize (const String &fileName, const StringList &directories)
											;
} // BOOST_PYTHON_MODULE(pixinsight)

//
// General conversions from/to python
//

// Conversion of pcl::String objects as suggested in
// http://misspent.wordpress.com/2009/09/27/how-to-write-boost-python-converters/
// FIXME currently, we only convert from/to str, we may want to add unicode
struct PCL_String_to_python_str
{
	static PyObject* convert(String const& s)
	{
		return incref(object(IsoString(s).c_str()).ptr());
	}
};

struct PCL_IsoString_to_python_str
{
	static PyObject* convert(IsoString const& s)
	{
		return incref(object(s.c_str()).ptr());
	}
};

// conversion of python string to PCL IsoString/String
template <class T1>
struct PCL_SomeString_from_python_str
{
	PCL_SomeString_from_python_str<T1>()
					 {
		converter::registry::push_back(
				&convertible,
				&construct,
				boost::python::type_id<T1>());
					 }

	// Determine if obj_ptr can be converted in a PCL::String
	static void* convertible(PyObject* obj_ptr)
	{
		if (!PyString_Check(obj_ptr)) return 0;
		return obj_ptr;
	}


	// Convert obj_ptr into a QString
	static void construct(
			PyObject* obj_ptr,
			converter::rvalue_from_python_stage1_data* data)
	{
		// Extract the character data from the python string
		const char* value = PyString_AsString(obj_ptr);
		// Verify that obj_ptr is a string (should be ensured by convertible())
		assert(value);
		// Grab pointer to memory into which to construct the new QString
		void* storage = ((converter::rvalue_from_python_storage<T1>*)data)->storage.bytes;
		// in-place construct the new String using the character data
		// extraced from the python object
		new (storage) T1(value);
		// Stash the memory chunk pointer for later use by boost.python
		data->convertible = storage;
	}
};

// conversion of Array<T> to list<T>
template<class T1>
struct PCL_ArrayToListConverter {
	static PyObject* convert(const Array<T1>& array) {
		list l;
		//std::cout<<"Converting Array"<<std::endl;
		typename Array<T1>::const_iterator p;
		for(p=array.Begin();p!=array.End();++p){
			//std::cout<<"Another object"<<p<<std::endl;
			l.append(object(*p));
		}
		return incref(l.ptr());
	}
};

//
// Utility functions for setting up the Python interpreter
//

/// initialize boost python converters. Done only once
void pyInitializeConverters()
{
	static bool bFirstCall=true;
	// make sure init happens only once
	if(bFirstCall)
	{
		//std::cout<<"registering converters"<<std::endl;
		bFirstCall=false;
		boost::python::to_python_converter<String,PCL_String_to_python_str>();
		boost::python::to_python_converter<IsoString,PCL_IsoString_to_python_str>();
		PCL_SomeString_from_python_str<String>();
		PCL_SomeString_from_python_str<IsoString>();
		boost::python::to_python_converter<Array<View>,PCL_ArrayToListConverter<View> >();
		boost::python::to_python_converter<Array<ImageWindow>,PCL_ArrayToListConverter<ImageWindow> >();

	}
}

/// redirect stdOut/err to Console
void pyRedirectIo()
{
	object consoleObject=consoleClass();

	static char stdOutStr[]="stdout";
	int res=PySys_SetObject(stdOutStr,consoleObject.ptr());
	if(res!=0){
		throw SourceCodeError("Cannot initialize stdout redirection"-1,-1);
	}
	static char stdErrStr[]="stderr";
	res=PySys_SetObject(stdErrStr,consoleObject.ptr());
	if(res!=0){
		throw SourceCodeError("Cannot initialize stderr redirection",-1,-1);
	}

}

/// initialize sys.path
void pySetSysPath()
{
	// FIXME adjust path and separators before release
	IsoString newPythonPath(String().Format("%s/%s",
						".",
						"PythonServer"));
	char pathName[]="path";
	PyObject *path=PySys_GetObject(pathName);
	if(path==NULL){
		throw SourceCodeError("Cannot get sys.path",-1,-1);
	}
	PyObject *newPathObject=PyString_FromString(newPythonPath.c_str());
	if(path==NULL){
		throw SourceCodeError("Cannot create path string",-1,-1);
	}
	int res=PyList_Insert(path,0,newPathObject);
	if(res!=0){
		throw SourceCodeError("Cannot add to sys.path",-1,-1);
	}
}
} //anonymous namespace for bindings

void pyInitialize()
{
	if(Py_IsInitialized()==0)
	{
		Py_InitializeEx(0); // dont init signal handlers, assuming PI is doing this
		// initialize pixinsight module
		initpixinsight_api();
		pyInitializeConverters();
		// do redirection
		// FIXME temporarily disabled due to threading problems
//		pyRedirectIo();
		pySetSysPath();
	}
}
