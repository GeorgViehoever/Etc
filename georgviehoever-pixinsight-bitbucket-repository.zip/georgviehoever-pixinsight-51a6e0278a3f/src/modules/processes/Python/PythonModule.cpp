/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#define MODULE_VERSION_MAJOR     00
#define MODULE_VERSION_MINOR     00
#define MODULE_VERSION_REVISION  03
#define MODULE_VERSION_BUILD     0003
#define MODULE_VERSION_LANGUAGE  eng

#define MODULE_RELEASE_YEAR      2012
#define MODULE_RELEASE_MONTH     12
#define MODULE_RELEASE_DAY       30

#include "PythonModule.h"
#include "PythonProcess.h"
#include "PythonInterface.h"

namespace pcl
{

// ----------------------------------------------------------------------------

PythonModule::PythonModule() : MetaModule()
{
}

const char* PythonModule::Version() const
{
   return PCL_MODULE_VERSION( MODULE_VERSION_MAJOR,
                              MODULE_VERSION_MINOR,
                              MODULE_VERSION_REVISION,
                              MODULE_VERSION_BUILD,
                              MODULE_VERSION_LANGUAGE );
}

IsoString PythonModule::Name() const
{
   return "Python2";
}

String PythonModule::Description() const
{
   return "PixInsight Python 2 Module";
}

String PythonModule::Company() const
{
   return "-";
}

String PythonModule::Author() const
{
   return "Georg Viehoever";
}

String PythonModule::Copyright() const
{
   return "Copyright (c) Georg Viehoever, 2012-2013";
}

String PythonModule::TradeMarks() const
{
   return "";
}

String PythonModule::OriginalFileName() const
{
#ifdef __PCL_LINUX
   return "Python-pxm.so";
#endif
#ifdef __PCL_FREEBSD
   return "Python-pxm.so";
#endif
#ifdef __PCL_MACOSX
   return "Python-pxm.dylib";
#endif
#ifdef __PCL_WINDOWS
   return "Python-pxm.dll";
#endif
}

void PythonModule::GetReleaseDate( int& year, int& month, int& day ) const
{
   year  = MODULE_RELEASE_YEAR;
   month = MODULE_RELEASE_MONTH;
   day   = MODULE_RELEASE_DAY;
}

// ----------------------------------------------------------------------------

} // pcl


PCL_MODULE_EXPORT int InstallPixInsightModule( int mode )
{
   new pcl::PythonModule;

   if ( mode == pcl::InstallMode::FullInstall )
   {
      new pcl::PythonProcess;
      new pcl::PythonInterface;
   }
   return 0;
}
