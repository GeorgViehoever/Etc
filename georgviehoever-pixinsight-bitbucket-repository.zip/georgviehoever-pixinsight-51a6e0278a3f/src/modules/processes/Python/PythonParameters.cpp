/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "PythonParameters.h"

namespace pcl
{

PythonParameter_UseSourceFile * ThePythonParameter_UseSourceFile=0;
PythonParameter_SourceFileName* ThePythonParameter_SourceFileName=0;
PythonParameter_ResetBefore* ThePythonParameter_ResetBefore=0;
PythonParameter_ResetAfter* ThePythonParameter_ResetAfter=0;
PythonParameter_Args* ThePythonParameter_Args=0;
PythonParameter_Source* ThePythonParameter_Source=0;

PythonParameter_UseSourceFile::PythonParameter_UseSourceFile( MetaProcess* P ) : MetaBoolean( P )
{
   ThePythonParameter_UseSourceFile = this;
}
IsoString PythonParameter_UseSourceFile::Id() const
{
   return "bUseSourceFile";
}

bool PythonParameter_UseSourceFile::DefaultValue() const
{
   return false;
}

PythonParameter_SourceFileName::PythonParameter_SourceFileName( MetaProcess* P ) : MetaString( P )
{
   ThePythonParameter_SourceFileName = this;
}
IsoString PythonParameter_SourceFileName::Id() const
{
   return "sSourceFileName";
}
size_type PythonParameter_SourceFileName::MinLength() const
{
   return 0;
}

String PythonParameter_SourceFileName::DefaultValue() const
{
	return "python3DPlot.py";
	//return "pythonEphemPlot.py";
}

PythonParameter_ResetBefore::PythonParameter_ResetBefore( MetaProcess* P ) : MetaBoolean( P )
{
   ThePythonParameter_ResetBefore = this;
}
IsoString PythonParameter_ResetBefore::Id() const
{
   return "bResetBefore";
}
bool PythonParameter_ResetBefore::DefaultValue() const
{
   return false;
}

PythonParameter_ResetAfter::PythonParameter_ResetAfter( MetaProcess* P ) : MetaBoolean( P )
{
   ThePythonParameter_ResetAfter = this;
}
IsoString PythonParameter_ResetAfter::Id() const
{
   return "bResetAfter";
}
bool PythonParameter_ResetAfter::DefaultValue() const
{
   return false;
}

PythonParameter_Args::PythonParameter_Args( MetaProcess* P ) : MetaString( P )
{
   ThePythonParameter_Args = this;
}
IsoString PythonParameter_Args::Id() const
{
   return "sArgs";
}
size_type PythonParameter_Args::MinLength() const
{
   return 0;
}

PythonParameter_Source::PythonParameter_Source( MetaProcess* P ) : MetaString( P )
{
   ThePythonParameter_Source = this;
}
IsoString PythonParameter_Source::Id() const
{
   return "sSource";
}
size_type PythonParameter_Source::MinLength() const
{
   return 0;
}

String PythonParameter_Source::DefaultValue() const
{
	return  "\"\"\" A Python Script. See Console for output.\n"
			"\"\"\"\n"
			"\n"
			"def execute_on(view):\n"
			"   print \"execute_on() called with view=%s\"%view.id\n"
			"   return True\n"
			"\n"
			"def execute_global():\n"
			"   import pixinsight_api as pi\n"
			"   print \"execute_global called\"\n"
			"   views=pi.View.all_views()\n"
			"   print \"Currently %d views are available with ids %s:\"%(len(views),map(lambda x: x.id,views))\n"
			"   return True\n"
			"\n"
			"import sys\n"
			"print \"hello world with argv=%s\"%sys.argv\n"
			//"import pixinsight as pi\n"
			//"print \"ViewById=\",pi.View.view_by_id(\"bla\")\n"
			//"print \"ViewById=\",pi.View.view_by_id(\"Mond_combined_3\")\n"
			;
			}
} // pcl

