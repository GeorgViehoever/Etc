#!/usr/bin/env python

from distutils.core import setup

setup(name='pixinsight',
      version='0.3',
      description='Python Bindings for PixInsight',
      author='Georg Viehoever',
      author_email='georg.viehoever@web.de',
      url='https://bitbucket.org/georgviehoever/pixinsight',
      packages=['pixinsight', 'pixinsight.server','pixinsight.client'],
      install_requires = ['rpyc>=3.2.3'],
      long_description="""Bindings for Python to PixInsight. Note: The API itself is distributed
      as a module with PixInsight (www.pixinsight.com). The module provided here adds the capability
      to separate client and server (=PixInsight), which is necessary to avoid binary incompatibilities
      between libraries. The tool used to communicate between client and server is RPyC http://pypi.python.org/pypi/rpyc/3.2.3.
      """,
      classifiers=[
          'Development Status :: 3 - Alpha',
          'Environment :: Other Environment',
          'Intended Audience :: End Users/Desktop',
          'Intended Audience :: Developers',
          'Intended Audience :: Science/Research',
          'License :: OSI Approved :: BSD License',
          'Natural Language :: English',
          'Operating System :: MacOS :: MacOS X',
          'Operating System :: Microsoft :: Windows',
          'Operating System :: POSIX :: Linux',
          'Operating System :: POSIX :: FreeBSD',
          'Programming Language :: Python :: 2.7',
          'Topic :: Scientific/Engineering :: Astronomy',
          'Topic :: Scientific/Engineering :: Visualization'
          'Topic :: Multimedia :: Graphics :: Editors :: Raster-Based'
          ],
     )
