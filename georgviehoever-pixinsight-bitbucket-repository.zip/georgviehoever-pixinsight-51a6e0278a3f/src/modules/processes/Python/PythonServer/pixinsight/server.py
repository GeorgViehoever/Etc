""" server class for PixInsight integration
"""
from rpyc.utils.server import OneShotServer

 # this is the current instance of client.Process after the client has connected to server.
 #
 # Before connect or after closing the connection, it is None
current_process=None

# this is the currently running server, None if not running
current_server=None

class server(object):
    """ start up subprocess and offer it pi_api services.
    
    The class is intended to be used with Process class in client,
    but using client.Process is not mandatory.
    
    Server supports the following use models:
    1. remote and local operation. The source code/script text/command may run
       in the same process as server (local), or it may run in a
       subprocess
    2. script, file based or cmmArgs: The source code that runs may be defined as a
       string or may be contained in a file. An alternative, specify argv vector of
       command to execute
    3. connected or unconnected: if the client source code creates a Process
       instance, it connects to this server. Otherwise, it is unconnected. The
       server terminates if the client process dies or if the connection is closed.
    4. if connected, the server may offer access to a pixinsight_api object or not.
       The ProcessInstance needs to handle that.
       
    Usual call sequence:
    1. construction with bLocal and script/fileName/cmdArgs set. This starts subprocesses
       as necessary, reads in the script/file, and offers to create a connection as necessary.
       Wait until connection is made.
    2. optionally if client connects: It may set current process
    3. optionally if current_process is available: call to server.execute_on(view) or server.execute_global(). 
       The server forwards these to current_process
    4. when no longer needed, call server.close(). Automatic close also happens if subprocess terminates
    """
    
    def __init__(self,bLocal,script=None,fileName=None, cmdArgs=None):
        """
        start subprocess with given script/fileName or cmdArgs. 
        
        Only one of script,fileName or cmdArgs may be !=None
        cmdArgs is expected to be a vector of arguments (such as sys.argv),
        script and fileName are string.
        cmdArgs is only supported for bLocal=False
        """
        from utils import CONNECTION_PAR_NAME
        global current_process
        global current_server
        
        nGivenArgs=(script!=None)+(fileName==None)+(cmdArgs!=None))
        if nGivenArgs!=1:
            raise ValueError("either script,fileName or cmdArgs must be given")
        if not bLocal and cmdArgs!=None:
            raise ValueError("cmdArgs only works with bLocal==False")
        
        current_process=None #current client.ProcessInstance instance that is connected to server
        current_server=None
        self._server=None # remote server himself
        self._thread=None # thread used by server for running
        self._subprocess=None # current subprocess in non-local mode
        if bLocal:
            # run script text of file locally
            if fileName!=None:
                with open(fileName,'r') as f:
                    return exec(f,globals())
            elif script!=None:
                return exec(f,globals())
            else:
                rause ValueError("unsupported source of commands for bLocal==False")
        else:
            env=self._start_server()
            self._launch_subprocess(env,script,fileName,cmdArgs)
        current_server=self
           
        def close(self):
            """ stop current server.
            """
            # FIXME need to look carefully for race conditions here
            global current_server
            global current_process
            
            if currentServer!=None:
                currentServer=None
                if current_process!=None:
                    current_process.close() #close client side if it exists
                    current_process=None
                if self._server!=None:
                    self._server.close() #close server side if client did not already do it
                    self._server=None
                if self.thread!=None:
                    self._thread.join()
                    self._thread=None
                current_process=None
        
        def _start_server():
            """ launches process that the remote process can connect to
                
            sets self._server and self._thread
                
            returns the environment that should be use to start the subprocess. This
            environment contains the connection parameters and a special PYTHHONPATH
            such that pixinsight.client can be found.
            """
            # Implementation note:    
            # The subprocess gets parameters for a connection (hostname, port, secret token)
            # in environment variable PIXINSIGHT_PYTHON_CON_PARS. The client can connect to
            # it using client.Process().
                
            # The server accepts exactly one connection, and terminates when the connection closes.
            # The server only accepts connections with the parameters in 
            # PIXINSIGHT_PYTHON_CON_PARS. This should give sufficient security.
 
            from rpyc.core.service import OneShotServer
            from pyc.classic import DEFAULT_SERVER_PORT
            from random import getrandbits
            from utils import CONNECTION_PAR_NAME
            from threading import Thread
            hostname='localhost'
            port=DEFAULT_SERVER_PORT
            secret=random.getrandbits(32)
            # FIXME need to add handling of secret here
            # FIXME implement finding free socket
            self._server=OneShotServer(hostname='0.0.0.0',port=port,service=rpyc.core.service.SlaveService)
            self._thread=Thread(target=self._server.start,name="PI Server Thread")
            self._thread.start()
                
            # determine suitable environment
            # start client process with con_params in environment variables
            from os import environ
            from os.path import abspath,dirname
            
            con_params="%s %d %d"%(hostname,port,secret)
            env=dict(environ)
            env[CONNECTION_PAR_NAME]=con_params
            myPythonPath=dirname(dirname(abspath(__file__)))
            env['PYTHONPATH']=myPythonPath
            # FIXME cleanup LD_LIBRARY_PATH to not contain PI libs?
            return env
                
        def _launch_subprocess(env,script,fileName,cmdArgs):
            """ launches subprocess in env, interpreting either script or fileName
            
            sets self._subprocess
            """

            import subprocess
            
            nGivenArgs=(script!=None)+(fileName==None)+(cmdArgs!=None))
            if nGivenArgs!=1:
                raise ValueError("either script,fileName or cmdArgs must be given")
            if fileName!=None:
                args=["python", fileName]
            elif script!=None:
                args=["python","-c",script]
            elif cmdArgs!=None:
                args=cmdArgs
            else:
                raise ValueError("one of script,fileName or cmdArgs must be !=None")
            self._subprocess=subprocess.Popen(args,env=env)
            # FIXME implement monitoring of subprocess
            

#
# some example configs. Easier to define here than in C++ executable...                
#
def serve_idle(bLocal=False,fileName=None):
    """ run IDLE
    """
    if bLocal:
        sys.argv=["idle","-n"]
        if fileName!=None:
            sys.argv.extend(["-e",fileName])
        script="""
        from idlelib.PyShell import main
        main()
        """
        server(bLocal,script=script)
    else:
        cmdArgs=["idle"]
        if fileName!=None:
            sys.argv.extend(["-e",fileName])
        server(bLocal,cmdArgs=cmdArgs)

def serve_spyder(bLocal=False, fileName=None):
    """ run spyder IDE
    """
    if not bLocal:
        raise ValueError("local mode not supported for Spyder: conflict of Qt versions")
    # FIXME need to set --session=xyz --workdir=wDir ?
    cmdArgs=["spyder"]
    if fileName!=None:
        sys.argv.extend([fileName])
    serve_subprocess(command_args=command_args)

if __name__=='__main__':
    """ for tests and documentation purposes
    
    simulate run with script, doing calls as done by PI.
    """
    
    script= r'''
    import pixinsight.client
    # set up TestProcessInstance class
    class TestProcessInstance(ProcessInstance):
        """ process instance that does nothing useful except print statements of items called
        """
        def __init__(self, argv, pi_api=None):
           print "TestProcessInstance.__init(self,%s,%s) called"%(argv,pi_api)
           super(TestProcessInstance,self).__init__(argv,pi_api)
           
        def execute_on(self,view):
            raise NotImplemented("execute_on() not implemented because we are not runnign with pi_api available")
    
        def execute_global(self):
            print "TestProcessInstance.execute_global(self) called"
            return True
    '''
    
    bLocal=True
    print 'starting server'
    server(bLocal,script)
    
    print 'starting serve_subprocess'
    serve_test()
    
    
    #serve_idle()
    #serve_spyder()
    print 'done subprocess'