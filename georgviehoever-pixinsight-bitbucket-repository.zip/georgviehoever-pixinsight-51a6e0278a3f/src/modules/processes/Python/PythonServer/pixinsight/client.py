""" client side module of the pixinsight connection
"""

class ProcessInstance(object):
    """ abstract base class for any process implementation

    implementations need to define at least one of execute_on(self,view) orf
    execute_global()
    """
    def __init__(self, argv, pi_api=None):
        """ initialize self with the use of the python api module
        
        argv is a vector of values that modifies the behaviour, for instance sys.argv
        _pi_api may be None of there is no access to PixInsight. Raise NotImplemented if
        your instance does not support this.
        """
        self._pi_api=pi_api
        self._argv=argv
        
    def execute_on(self,view):
        """ implement this for process to be run on specific view (Apply or drag blue triangle)
        
        Cannot be called if _pi_api is None, since View is a PixInsight object 
        returns True for success, False otherwise
        """
        raise NotImplemented("method execute_on() not implemented for this process instance")
    
    def execute_global(self):
        """ implement this for process to be run globallay (Apply Global)
        
        Can be called even if _pi_api is unset, since this does not necessarily need
        access to PixInsight objects
        returns True for success, False otherwise
        """
        raise NotImplemented("method execute_global() not implemented for this process instance")

class EmptyProcessInstance(ProcessInstance):
    """ process instance that does nothing. Useful for example to implement a pure script
    """
    def execute_on(self,view):
        return True
    def execute_global(self):
        return True
    def run_callable(self,callable):
        """ run callable(argv,pi_api). pi_api may be None. callable returns True for success, False otherwise
        """
        return callable(self._pi_api,self._argv)

class Process(object):
    """Process is the collection of objects that constitute a complete process
    
    The plan is provide the meta description, the parameters and the GUI functionality in
    very much the same way that the corresponding PCL classes do. For the moment, we only
    have the process instance
    
    Note: There can be only one Process instance per PI python module
    This class will also work if there is no actual connection to the server. In this case,
    _conn and _pi_api are None
    """
    
    def __init__(self, process_instance_class):
        """ connect to server and initialize with the description of the process to be executed.
        
        process instance_class is the process_instance *class* that can execute the process.
        For the details of creating a server connection, see self.connect_to_server()
        """
        self._conn=None # connection to server
        self._pi_api=None #python api module
        self.process_instance_class=process_instance_class;
        self._connect_to_server()

    def get_process_instance(self,argv):
        """ return process_instance ininitalized with (self._pi_api,argv)
        
        pi_api may be none of there is no connection to a server
        """
        return self.process_instance_class(argv,self._pi_api)

    def close(self):
        """ close connection to server and reset everything- Connection cannot be recreated
        """
        if self._conn!=None:
            self._conn.close()
            self._conn=None
        self._pi_api=None
        self.process_instance_class=None
        
    def _connect_to_server(self,redirect_to_server=True):
        """open rpyc client connection to server, redirect I/O, retrieve py_api and register self on server side.
        
        The connection parameters are given in environment variable named by utils.CONNECTION_PAR_NAME 
        if redirect_to_server=True, then redirect sys.stdout/stderr to server, otherwise leave it local.
        self is registered on server in class variable current_process.
        If the environment variable is not set, redirect_to_server is ignored and self._conn is None.
        A import of a local pixinsight_api is attempted. If this fails, self._pi_api is None. 
        
        No error message is produced if there is no pi_api. It is up to the ProcessInstance to respond
        with an error message if it cannot handle an environment.
        
        Note: it should be make no difference to the ProcessInstance if pi_api is local or remote. But
        it may be None in any case.
        """
        
        from utils import CONNECTION_PAR_NAME
        import os
        import rpyc
        import sys
    
        env=os.environ
        if env.has_key(CONNECTION_PAR_NAME):
            # create connection to remote server
            con_params=env[CONNECTION_PAR_NAME]
            (host,port,secret)=con_params.split()
            port=int(port)
            secret=int(secret)
            # FIXME handling of secret not yet implemented
            self._conn=rpyc.classic.connect(host,port)
            #optionally do redirection
            if redirect_to_server:
                ssys=self._conn.modules.sys 
                ssys=self._conn.modules.sys 
                sys.stdout=ssys.stdout
                sys.stderr=ssys.stderr
                sys.stdin=ssys.stdin
            # register self with server
            sserver=self._conn.modules.pixinsight.server
            sserver.current_process=self
            try:
                # this may be a server that does not offer any PI functionality
                self._pi_api=conn.modules.pixinsight_api
            except:
                pass
        else:
            #local run we permit case without pixinsigt_api as well
            try:
                import pixinsight_api
                self._pi_api=pixinsight_api
            except:
                pass
            # make self known on server. server may or may not exist
            try:
                import server
                server.current_process=self
            except:
                print "no server found"
                pass

if __name__=='__main__':
    """ For test and documentation purposes
    
    Simulates the sequence of calls that would also be performed by a PixInsight server.
    """
    
    import sys
    print "sys.argv=",sys.argv
    print "running simulation of server calls"
    # set up TestProcessInstance class
    class TestProcessInstance(ProcessInstance):
        """ process instance that does nothing useful except print statements of items called
        """
        def __init__(self, argv, pi_api=None):
           print "TestProcessInstance.__init(self,%s,%s) called"%(argv,pi_api)
           super(TestProcessInstance,self).__init__(argv,pi_api)
           
        def execute_on(self,view):
            raise NotImplemented("execute_on() not implemented because we are not runnign with pi_api available")
    
        def execute_global(self):
            print "TestProcessInstance.execute_global(self) called"
            return True
    
    testProcess=Process(TestProcessInstance)
    # now simulate the call sequence that a PI server would use
    print "server getting instance"
    instance=testProcess.get_process_instance(sys.argv)
    print "server performing execute_global()"
    instance.execute_global()
    print "server shutting down process"
    testProcess.close()
    print "done"
    