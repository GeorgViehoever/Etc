# pixinsight module initialization
print "__init__.py for pixinsight "
print "init.__path__=",__path__
pixinsight_path=__path__[0]
