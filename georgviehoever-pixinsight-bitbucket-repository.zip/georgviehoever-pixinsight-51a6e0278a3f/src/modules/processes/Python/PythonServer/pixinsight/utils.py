""" shared utilities for client and server
"""

# name of environment variable that hold connection parameters for client
CONNECTION_PAR_NAME='PIXINSIGHT_PYTHON_CON_PARS'
