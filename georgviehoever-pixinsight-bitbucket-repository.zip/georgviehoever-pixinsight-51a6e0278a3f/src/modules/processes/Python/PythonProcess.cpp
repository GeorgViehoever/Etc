/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "PythonProcess.h"
#include "PythonParameters.h"
#include "PythonInstance.h"
#include "PythonInterface.h"

#include <pcl/Console.h>
#include <pcl/Arguments.h>
#include <pcl/View.h>
#include <pcl/Exception.h>

//#include <iostream>

namespace pcl
{

// ----------------------------------------------------------------------------

//#include "PythonIcon.xpm"

// ----------------------------------------------------------------------------

PythonProcess* ThePythonProcess = 0;

// ----------------------------------------------------------------------------

PythonProcess::PythonProcess() : MetaProcess()
{
   ThePythonProcess = this;

   // Instantiate process parameters
   new PythonParameter_UseSourceFile(this);
   new PythonParameter_SourceFileName(this);
   new PythonParameter_ResetBefore(this);
   new PythonParameter_ResetAfter(this);
   new PythonParameter_Args(this);
   new PythonParameter_Source(this);
}

// ----------------------------------------------------------------------------

IsoString PythonProcess::Id() const
{
   return "Python";
}

// ----------------------------------------------------------------------------

IsoString PythonProcess::Category() const
{
   return IsoString(); // No category
}

// ----------------------------------------------------------------------------

uint32 PythonProcess::Version() const
{
   return 0x100; // required
}

// ----------------------------------------------------------------------------

String PythonProcess::Description() const
{
   return

   "<html>"
   "<p>Python permits to execute Python scripts in the context of PixInsight. It also offers"
		   " access to certain PCL objects, for instance Views.</p>"
   "</html>";
}

// ----------------------------------------------------------------------------

const char** PythonProcess::IconImageXPM() const
{
   return 0; // PythonIcon_XPM; ---> put a nice icon here
}
// ----------------------------------------------------------------------------

ProcessInterface* PythonProcess::DefaultInterface() const
{
   return ThePythonInterface;
}
// ----------------------------------------------------------------------------

ProcessImplementation* PythonProcess::Create() const
{
   return new PythonInstance( this );
}

// ----------------------------------------------------------------------------

ProcessImplementation* PythonProcess::Clone( const ProcessImplementation& p ) const
{
   const PythonInstance* instPtr = dynamic_cast<const PythonInstance*>( &p );
   return (instPtr != 0) ? new PythonInstance( *instPtr ) : 0;
}

// ----------------------------------------------------------------------------

bool PythonProcess::CanProcessCommandLines() const
{
   return true;
}

// ----------------------------------------------------------------------------

static void ShowHelp()
{
   Console().Write(
"<raw>"
"Usage: Python [<arg_list>] [viewId]"
"\n Executes Python commands, globally or optionally on defined view"
"\n-i, --interface:          Launches the interface of this process."
"\n-h, --help:               Displays this help and exits."
// "\n-b, --reset-before:       Reset before executing Python"
// "\n-a, --reset-after:        Reset after executing Python"
"\n-f <file>, --file <file>: Python script file to execute"
"\n-p=<params>, --parameter=<params>: set sys.argv to params"
"\n-c=<command>, --command=<command> : Python command to execute"
"</raw>" );
}


int PythonProcess::ProcessCommandLine( const StringList& argv ) const
{
   ArgumentList arguments =ExtractArguments( argv,ArgumentItemMode::AsViews);
//std::cout<<"argv="<<argv<<std::endl;
   PythonInstance instance( this );

   bool launchInterface = false;
   bool isFile=false;
   bool isCommand=false;
   View v;

   for ( ArgumentList::const_iterator i = arguments.Begin(); i != arguments.End(); ++i )
   {

      const Argument& arg = *i;
  //    std::cout<<"argid="<<arg.Id()<<std::endl;

      if ( arg.IsNumeric() )
      {
         throw Error( "Unknown numeric argument: " + arg.Token() );
      }
      else if ( arg.IsString() )
      {
    	  if ( arg.Id() == "-file" ||arg.Id() == "f"){
    		  if(isCommand){
    			  throw Error( "Cannot have both -c and -f: " + arg.Token() );
    		  }
    		  isFile=true;
    		  instance.sSourceFileName=arg.StringValue();
    		  instance.bUseSourceFile=true;
    	  } else if ( arg.Id() == "-command" ||arg.Id() == "c"){
    		  if(isFile){
       			  throw Error( "Cannot have both -c and -f: " + arg.Token() );
    		  }
    		  isCommand=true;
    		  instance.sSource=arg.StringValue();
    		  instance.bUseSourceFile=false;
    	  } else if ( arg.Id() == "-parameter" ||arg.Id() == "p"){
    		  instance.sArgs=arg.StringValue();
    	  } else {
    		  throw Error( "Unknown string argument: " + arg.Token() );
    	  }
      }
      else if ( arg.IsSwitch() )
      {
         throw Error( "Unknown switch argument: " + arg.Token() );
      }
      else if ( arg.IsLiteral() )
      {
         // These are standard parameters that all processes should provide.
         if ( arg.Id() == "-interface"  ||arg.Id() == "i")
            launchInterface = true;
         else if ( arg.Id() == "-help" ||arg.Id() == "h")
         {
            ShowHelp();
            return 0;
         }
         else
         {
            throw Error( "Unknown argument: " + arg.Token() );
         }
      }
      else if ( arg.IsItemList() )
      {
    	  if(arg.Items().Length() !=1){
    		  throw Error( "Accepts at most one viewId: got" + String(arg.Items().Length()) );
         }
    	 v=View::ViewById(arg.Items()[0]);
      }
   }

   if ( launchInterface )
      instance.LaunchInterface();
   else {
      if ( v.IsNull() ){
    	  instance.LaunchGlobal();
      } else {
    	  instance.LaunchOn(v);
      }
   }

   return 0;
}

// ----------------------------------------------------------------------------

} // pcl

