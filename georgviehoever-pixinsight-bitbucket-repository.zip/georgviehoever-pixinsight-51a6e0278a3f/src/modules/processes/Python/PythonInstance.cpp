/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "PythonInstance.h"

#ifdef __PCL_LINUX
// for dlopen
#include <dlfcn.h>
#endif

// for integration of PI as module PI
#include <boost/python.hpp>

#include "PythonParameters.h"
#include "PythonBindings.h"


namespace pcl
{

// ----------------------------------------------------------------------------

PythonInstance::PythonInstance( const MetaProcess* m ) :
ProcessImplementation( m ),
bUseSourceFile(ThePythonParameter_UseSourceFile->DefaultValue()),
sSourceFileName(ThePythonParameter_SourceFileName->DefaultValue()),
bResetBefore(ThePythonParameter_ResetBefore->DefaultValue()),
bResetAfter(ThePythonParameter_ResetAfter->DefaultValue()),
sArgs(ThePythonParameter_Args->DefaultValue()),
sSource(ThePythonParameter_Source->DefaultValue())
{
}

PythonInstance::PythonInstance( const PythonInstance& x ) :
ProcessImplementation( x )
{
   Assign( x );
}

void PythonInstance::Assign( const ProcessImplementation& p )
{
   const PythonInstance* x = dynamic_cast<const PythonInstance*>( &p );
   if ( x != 0 )
   {
	  bUseSourceFile  = x->bUseSourceFile;
	  sSourceFileName = x->sSourceFileName;
	  bResetBefore = x->bResetBefore;
	  bResetAfter = x->bResetAfter;
	  sArgs = x->sArgs;
	  sSource = x->sSource;
   }
}

bool PythonInstance::CanExecuteGlobal(String &whyNot) const
{
	whyNot.Clear();
	if(bUseSourceFile){
		// test if we can read the file. We cannot check on syntax or other python related things, and we
		// dont require execute permission here.
		try
		{
			if(!File(sSourceFileName,FileMode::Read).CanRead()){
				//std::cout<<"stop in if"<<std::endl;
				whyNot="Cannot read source file";
				return false;
			}
		} catch (Exception &e) {
			// FIXME should throw FileException. Bug in PCL1.85, fixed in PCL2.0
			std::cout<<"caught "<<e.Message()<<std::endl;
			whyNot=e.Message();
			return false;
		}
	}
	return true;
}

bool PythonInstance::CanExecuteOn(const View &view, String &whyNot) const
{
	if(view.IsNull()){
		whyNot="Cannot execute on empty view.";
		return false;
	}
	return CanExecuteGlobal(whyNot);
}

bool PythonInstance::staticExecuteGlobal(bool bResetBefore_p, bool bResetAfter_p,bool bUseSourceFile_p,
		std::string const &rsFileName_p, std::string const &rsSource_p, StringVec_t const & rArgv_p,
		bool bRunMethod_p,bool bExecuteGlobal_p, View *pView_p)
{
	 bool retVal=true;


#ifdef __PCL_LINUX
	 // workaround as described in http://bugs.python.org/msg76454
	 // FIXME this is UNIX specific code. May not be necessary for Windows and others
	 dlopen("libpython2.7.so", RTLD_LAZY |RTLD_GLOBAL);
#endif
	 if (Py_IsInitialized()!=0 && bResetBefore_p)
	 {
		 // FIXME Finalize causes all kinds of problems, because libs are not prepared for this. Find
		 // alternative way to clear Python data before running anything else
		 Py_Finalize();
	 }
	 pyInitialize();
	 // convert to char **
	 const std::size_t argc=rArgv_p.size();
	 std::vector<char *> cPointers(argc);
	 for(std::size_t i=0;i<argc;++i)
	 {
		 //std::cout<<"argv["<<i<<"]="<<argv[i]<<std::endl;
		 cPointers[i]=const_cast<char *>(&(rArgv_p[i][0]));
	 }

	 PySys_SetArgvEx(argc,&(cPointers[0]),0);
	 std::string sProblemName="undefined";
	 try
	 {
		 // first read in source code, then optionally run execute_global() or execute_on()
		 // FIXME more elaborate error handling, see:
		 // -http://misspent.wordpress.com/2009/10/11/boost-python-and-handling-python-exceptions/
		 // -http://thejosephturner.com/blog/2011/07/18/embedding-python-in-c-applications-with-boostpython-part-4/

		 sProblemName="Problem when importing __main_";
		 boost::python::object main_module = boost::python::import("__main__");
		 sProblemName="Problem accessing __main__.__dict__";
		 boost::python::object main_namespace = main_module.attr("__dict__");
		 if(bUseSourceFile_p)
		 {
			 sProblemName="Problem while executing Python file";
			 boost::python::exec_file(boost::python::str(rsFileName_p),main_namespace);
		 } else {
			 sProblemName="Problem while executing Python string";
			 boost::python::exec(boost::python::str(rsSource_p),main_namespace);
		 }
		 if(bRunMethod_p)
		 {

			 if(bExecuteGlobal_p){
				 // execute_global()
				 sProblemName="Problem finding execute_global()";
				 boost::python::object f=main_module.attr("execute_global");
				 sProblemName="Problem while executing execute_global()";
				 if (!PyFunction_Check(f.ptr())){
					 throw SourceCodeError("execute_global is not a function",-1,-1);
				 }
				 boost::python::object res=f();
				 sProblemName="Problem converting result of execute_global() to boolean";
				 retVal=boost::python::extract<bool>(res);
			 } else {
				 // execute_on(view)
				 if(pView_p==NULL){
					 throw SourceCodeError("execute_on() expects View != NULL",-1,-1);
				 }
				 sProblemName="Problem finding execute_on()";
				 boost::python::object f=main_module.attr("execute_on");
				 sProblemName="Problem while executing execute_on()";
				 if (!PyFunction_Check(f.ptr())){
					 throw SourceCodeError("execute_on is not a function",-1,-1);
				 }
				 boost::python::object res=f(*pView_p);
				 sProblemName="Problem converting result of execute_on() to boolean";
				 retVal=boost::python::extract<bool>(res);
			 } // bExecuteGlobal
		 } // bRunMethod
		 // FIXME we may need some method to reset the interpreter as much as possible.
		 // Py_Finalize() is not a good idea because of loaded .so's
	 } catch (boost::python::error_already_set const &) {
		 std::string sMessage=sProblemName+" (see console for details)";
		 PyErr_PrintEx(true);
		 throw SourceCodeError(sMessage.c_str(),-1,-1);
	 }  //catch
	 if(bResetAfter_p)
	 {
		 Py_Finalize();
	 }
	 return retVal;
}

bool PythonInstance::ExecuteGlobal()
{
	StringVec_t argv=getArgv();
	const std::string sourceFileName(IsoString(sSourceFileName).c_str());
	const std::string sourceString(IsoString(sSource).c_str());
	return staticExecuteGlobal(bResetBefore, bResetAfter, bUseSourceFile,
		sourceFileName,sourceString,argv,true,true,NULL);
}

bool PythonInstance::ExecuteOn( View& rView_p )
{
	StringVec_t argv=getArgv();
	const std::string sourceFileName(IsoString(sSourceFileName).c_str());
	const std::string sourceString(IsoString(sSource).c_str());
	return staticExecuteGlobal(bResetBefore, bResetAfter, bUseSourceFile,
		sourceFileName,sourceString,argv,true,false,&rView_p);
}

void* PythonInstance::LockParameter( const MetaParameter* p, size_type /*tableRow*/ )
{
	if (p == ThePythonParameter_UseSourceFile)
		return &bUseSourceFile;
	if (p == ThePythonParameter_SourceFileName)
		return &sSourceFileName;
	if (p == ThePythonParameter_ResetBefore)
		return &bResetBefore;
	if (p == ThePythonParameter_ResetAfter)
			return &bResetAfter;
	if (p == ThePythonParameter_Args)
			return &sArgs;
	if (p == ThePythonParameter_Source)
			return &sSource;

    return 0;
}

bool PythonInstance::AllocateParameter( size_type sizeOrLength, const MetaParameter* p, size_type tableRow )
{
	if ( p == ThePythonParameter_SourceFileName )
	{
		sSourceFileName.Clear();
		if ( sizeOrLength > 0 )
			sSourceFileName.Reserve( sizeOrLength );
	} else 	if ( p == ThePythonParameter_Args )
	{
		sArgs.Clear();
		if ( sizeOrLength > 0 )
			sArgs.Reserve( sizeOrLength );
	} else 	if ( p == ThePythonParameter_Source )
	{
		sSource.Clear();
		if ( sizeOrLength > 0 )
			sSource.Reserve( sizeOrLength );
	} else {
      return false;
	}
   return true;
}

size_type PythonInstance::ParameterLength( const MetaParameter* p, size_type tableRow ) const
{
	if ( p == ThePythonParameter_SourceFileName )
		return sSourceFileName.Length();
	else 	if ( p == ThePythonParameter_Args )
		return sArgs.Length();
	else 	if ( p == ThePythonParameter_Source )
		return sSource.Length();
   return 0;
}

void PythonInstance::runIdle()
{
	// FIXME there are problems on the second invocation, maybe related to tk.
	// See SIGSEGV(11), or
	// bgerror failed to handle background error.
    // Original error: invalid command name "155720752callit"
    // Error in bgerror: can't invoke "tk" command:  application has been destroyed
	// I may need to remove this functionality.

	StringVec_t argv(2);
	argv[0]="";
	// FIXME: option to run in-process may disappear with Python 3.4
	argv[1]="-n"; //run in_process.
	if(bUseSourceFile)
	{
		argv.push_back("-e"); //edit mode
		argv.push_back(std::string(IsoString(sSourceFileName).c_str()));;
	}
	runIde(getIdleString(),argv);
}

void PythonInstance::runSpyder()
{
	// FIXME: currently fails with
	//  Traceback (most recent call last):
	//  File "<string>", line 1, in <module>
	//  File "/usr/lib/python2.7/site-packages/spyderlib/spyder.py", line 74, in <module>
	//    from spyderlib.qt.QtGui import (QApplication, QMainWindow, QSplashScreen,
	//  File "/usr/lib/python2.7/site-packages/spyderlib/qt/QtGui.py", line 10, in <module>
	//    from PyQt4.Qt import QKeySequence, QTextCursor
	//ImportError: cannot import name QKeySequence
	// Version mismatch with PI Qt?

	StringVec_t argv(1);
	argv[0]="";
	runIde(getSpyderString(),argv);
}

// ----------------------------------------------------------------------------


/// return string used to start up Idle shell
 std::string const & PythonInstance::getIdleString() const
 {
	 // this is the text from /usr/bin/idle
	 static const std::string sIdle(
			 "from idlelib.PyShell import main\n"
			 "if __name__ == '__main__':\n"
			 "	main()\n"
	 	 );
	 return sIdle;
 }

 /// return string for startup of Spyder shell
 std::string const & PythonInstance::getSpyderString() const
 {
	 // this is the text from /usr/bin/spyder
	 static const std::string sSpyder(
			 "from spyderlib import spyder\n"
			 "spyder.main()"
		);
	 return sSpyder;
 }

 void PythonInstance::runIde(const std::string &rsIdeString_p, const PythonInstance::StringVec_t &rArgv_p)
 {
	 // workaround as described in http://bugs.python.org/msg76454
	 staticExecuteGlobal(true, true,false,
	     		"", rsIdeString_p,rArgv_p);
 }

 PythonInstance::StringVec_t PythonInstance::getArgv() const
 {
	 // Note: This version just splits at " ". It does not do fancy evaluation
	 // of strings or escape sequences. Maybe later
	 StringList argvList;
	 // Note: Following does not work with " " instead of ' ' due to bug in PCL1.85
	 sArgs.Break(argvList,' ',true);
	 const std::size_t argc=argvList.Length()+1;
	 StringVec_t argv(argc);
	 argv[0]=""; //program name
	 for(std::size_t i=1;i<argc;++i)
	 {
		 //std::cout<<"arg="<<argvList[i-1]<<std::endl;
		 argv[i]=IsoString(argvList[i-1]).c_str();
	 }
	 return argv;
 }


} // pcl
