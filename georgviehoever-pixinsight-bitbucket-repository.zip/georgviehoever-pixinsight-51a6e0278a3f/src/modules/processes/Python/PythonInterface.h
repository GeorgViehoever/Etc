/* Copyright (c) 2012 Georg Viehoever.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef __PythonInterface_h
#define __PythonInterface_h

// define if you want to use the PCL2.0 code editor instead of textbox
#define USE_CODE_EDITOR

#include <pcl/ProcessInterface.h>

#include <pcl/Sizer.h>
#include <pcl/PushButton.h>
#include <pcl/ToolButton.h>
#include <pcl/Label.h>
#ifdef USE_CODE_EDITOR
   #include <pcl/CodeEditor.h>
#else
   #include <pcl/TextBox.h>
#endif
#include <pcl/NumericControl.h>
#include <pcl/SpinBox.h>
#include <pcl/CheckBox.h>
#include <pcl/ComboBox.h>
#include <pcl/Edit.h>

#include "PythonInstance.h"


namespace pcl
{

// ----------------------------------------------------------------------------
// PythonInterface
// ----------------------------------------------------------------------------

class PythonInterface : public ProcessInterface
{
public:

   PythonInterface();
   virtual ~PythonInterface();

   virtual IsoString Id() const;
   virtual MetaProcess* Process() const;
   virtual const char** IconImageXPM() const;
   virtual InterfaceFeatures Features() const;

   virtual void ApplyInstance() const;
   virtual void ResetInstance();

   virtual bool Launch( const MetaProcess&, const ProcessImplementation*, bool& dynamic, unsigned& /*flags*/ );

   virtual ProcessImplementation* NewProcess() const;

   virtual bool ValidateProcess( const ProcessImplementation&, String& whyNot ) const;
   virtual bool RequiresInstanceValidation() const;

   virtual bool ImportProcess( const ProcessImplementation& );

private:

   PythonInstance instance;

   struct GUIData
   {
      GUIData( PythonInterface& );

      VerticalSizer     Global_Sizer;
      	 // button for starting python shells
         HorizontalSizer   ShellButtons_Sizer;
         	 Label			   IDE_Label;
      	 	 PushButton        Idle_PushButton;
      	 	 PushButton        Spyder_PushButton;

      	 HorizontalSizer   InputFile_Sizer;
         	 CheckBox          InputFile_CheckBox;
             //Label             InputFile_Label;
             Edit              InputFile_Edit;
             ToolButton        InputFile_ToolButton;
        HorizontalSizer   Reset_Sizer;
        	CheckBox          ResetBefore_CheckBox;
        	CheckBox          ResetAfter_CheckBox;
        HorizontalSizer   Args_Sizer;
        	Label             Args_Label;
            Edit              Args_Edit;
        HorizontalSizer   Source_Sizer;
#ifdef USE_CODE_EDITOR
            CodeEditor           Source_TextBox;
#else
            TextBox           Source_TextBox;
#endif
   };

   GUIData* GUI;

   void UpdateControls();

   // Event Handlers

   /// callback for idle button
   void __IdleButton_Pressed(PushButton & sender);
   /// callback for spyder button
   void __SpyderButton_Pressed(PushButton & sender);

   /// callback for file selection CheckBox
   void __InputFileCheckBox_Clicked( Button& sender, bool checked );
   /// callback for file selection
   void __InputFileEdit_Completed( Edit& sender );
   /// callback for file selection
   void __InputFileToolButton_Clicked( Button& sender, bool checked );

   /// callback for reset-before CheckBox
   void __ResetBeforeCheckBox_Clicked( Button& sender, bool checked );
   /// callback for reset-after CheckBox
   void __ResetAfterCheckBox_Clicked( Button& sender, bool checked );

   /// callback for args field
   void __Args_EditCompleted( Edit& sender );

   /// callback for Source Textbox/CodeEditor
   void __Source_LoseFocus( Control &sender);

   void __RealValueUpdated( NumericEdit& sender, double value );
   void __IntegerValueUpdated( SpinBox& sender, int value );
   void __ItemClicked( Button& sender, bool checked );
   void __ItemSelected( ComboBox& sender, int itemIndex );
   void __EditGetFocus( Control& sender );
   void __EditCompleted( Edit& sender );

   friend struct GUIData;
};

// ----------------------------------------------------------------------------

PCL_BEGIN_LOCAL
extern PythonInterface* ThePythonInterface;
PCL_END_LOCAL

// ----------------------------------------------------------------------------

} // pcl

#endif

