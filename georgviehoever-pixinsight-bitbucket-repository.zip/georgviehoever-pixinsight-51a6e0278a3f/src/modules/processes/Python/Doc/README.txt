
PixInsight Python Module
========================

Version 0.2
Date: 2012-12-30
Author: Georg Viehoever

This is an alpha release of a Python http://www.python.org/download/releases/2.7.3/ 
language extension for PixInsight. Python is a scripting language that is hugely popular
in scientific computing and many other areas. It is well defined, modern and powerful. As such,
I hope it is a powerful extension for PixInsight.

I am releasing this module in alpha state in the hope to find collaborators that help to
advance development of this module. See section "Development" below.

Features:
---------

- Allows to run Python 2.7 scripts within PixInsight

- all provided and used software has licenses compatible with use in PixInsight.

- Python scripts can access PCL classes for creating and manipulating images

- Python with PixInsight can use many popular Python extensions such an numpy http://numpy.scipy.org/,
  scipy http://www.scipy.org/, matplotlib http://matplotlib.org/, pyephem http://rhodesmill.org/pyephem/,
  and other modules such as those from PiPy http://pypi.python.org/pypi.
  Those module can do many useful tasks such as solving equation
  systems, image processing, plotting graphs, and computing the ephemerides of celestial objects.
  They save a lot of work/lines of code. JavaScript and other scripting languages
  are not nearly as strong in this domain. See the examples for proof.
  
- PixInsight can pass parameters as sys.argv to Python

- Python output (print, error messages) goes to the PixInsight console

- Depending on local (blue rectangle/drag blue triangle) or global execution (blue circle), different methods in Python 
  (execute_on()/execute_global()) are called.

- New Instance (blue triangle) also works as with normal processes.

- A Python IDE (IDLE, with context help etc) can be used to edit scripts

- The following PCL objects are bound to corresponding Python objects:
  - pcl::String/IsoString <-> str
  - pcl::Array<type> -> list where elements are the correspondingly translated Python types
  - pcl::Exception <-> Exception. A Python Exception raises a pcl::SourceCodeError
  - pcl::ImageWindow <-> ImageWindow
  - pcl::View <-> View
  - pcl::ImageVariant <-> Image
  - method names have been translated to Python naming convention, e.g. GetLuminance()->get_luminance().
    The methods that have been translated currently are only a small subset of those available.
 
 - some basic help is available for instance via help(View) in Python
 
 - Execution of a script happens as follows:
   - read in script, with sys.argv set as defined by user. This will execute code in the __Main__ module.
   - For Apply() (drag blue triangle on Image, blue rectangle), execute_on(view) is called. 
   - For global apply (blue circle), execute() is called.
   - Both return True for success, or False if something goes wrong. PI responds to this as usual.
   - Errors and Exceptions are captured and forwarded to PCL.
 
 - The execution model should enable use with ImageContainer (not tested yet)

 - The execution model should (at some time) allow writing proper PixInsight processes in Python
 
This is an Alpha Release!
-------------------------

This is a very early release of this module. Problems are to be expected. At this stage, the
module should only be used by those that are bold and stress resistant (such as developers).

Known problems:

- so far only developed on Fedora 17-x64 Linux. No attempt porting it to other platforms,
  in particular Windows or MacOS, has been made. However, it should be possible to port the
  software to any PI platform: The supporting modules are available for them as well.
  
- On Fedora 17-x64, the module cannot be compiled with the default gcc v. 4.7.2. Doing so results
  in a SIGSEGV when loading the module. This most likely is a gcc/PCL issue. I am using gcc 4.6.3 to compile
  the module.

- The language bindings cover only a small part of the PCL interface. I implemented only what was
  needed for the example scripts, or what was trivial.

- There are known problems. In particular:

  - Image.get_luminance() does not work for unknown reasons

  - After the use of the IDLE gui, we sometimes get SIGSEGV (11). Scripts outside IDL work without problems
    though. This needs further investigation.

  - There are incompatibilities between library versions. For instance, Python must not use any library
    that uses Qt (such as PyQt), because PixInsight is using an incompatible version

- only rudimentary tests have been performed.


Use:
----

Here some explanations on how to use the current module:

- The module appears as "Python" in the module list. Selecting it opens the GUI shown in gui.JPG.

- GUI Elements:

  - IDLE button: If pressed, opens the IDLE development environment. NOTE: This still frequently crashed. Be careful!
    -If Use File is selected, it opens an editor with syntax coloring for the selected file (idleEditor.JPG)
    -If Use File is not selected, it opens in interactive mode with context help (idleInteractive.JPG)

  - Use File checkbox: If selected, the selected file contains the Python script to be executed. Otherwise, the script
    text contained in the TextBox at the bottom of the dialog is executed. File selection happens with a standard
    file selection dialog.

  - Arguments: blank separated arguments that are passed to the script sys.argv, just like command line arguments would
    be passed to a shell script.

  - Text box: Enter your script text here if Use File is not selected.

  - Apply Global (blue circle), Apply (blue rectangle) and New Instance (Blue Triangle) can be used as usual.
    See under "Features" on what happens on Apply/Apply Global.


Examples:
---------

The module comes with 3 examples.

1. Code in the text box. This code is written to demonstrate how Python is executed and how PCL objects can be access.
   Output is printed to the Console Window. See applyGlobal.JPG for the script and the results of an Apply Global.

2. python3DPlot.py: is a re-implementation of the 3DPlot.js script that comes with PI. Instead of 722 lines of code
   it needs just 51 lines (!), and allows to rotate and zoom the plot interactively. It uses the Python matplotlib
   to do this. See python3DPlot.JPG for a screenshot showing the result of the .js script on the right, and the
   interactive Python display on the left.
   
3. pythonEphemPlot.py: This a module that computes sunset/sunrise times plus moon/planet visibilities for a year of your choice.
   The expected darkness is plotted as a background, based on the sun position (twilight) and moon position/phase.
   The rising/setting times for each celestial object are plotted as colored lines. A legend explains which line
   has which meaning.
   
   The heavy lifting is done by the libraries pyEphem (celestial calculations) and matplotlib (graphics). The whole 
   program is 422 lines of code (including help texts, command line evaluation, ...).
   
   Select the year for your plot by specifying -y <year> as an argument. Additional options allow to specify your
   location. Use option -h to see those parameters. The screenshot pythonEphemPlot.JPG shows
   the graph for 2013 in Munich.
   
   BTW: this script not only works within PI. You can also use it directly from the shell command line. Make your
   own visibilities plot for next year even if you do not want to use the PI module (yet)!
 
 
Development:
------------

This section explains how to build and extend the module.

- The module sources are available on BitBucket https://bitbucket.org/georgviehoever/pixinsight, 
  version controlled using Mercurial. If you want to join development of this module, you are encouraged
  to use Mercurial as well. If you do not want to do that: Feel free to send changes. (Thanks to Bitli for
  introducing me to BitBucket/Mercurial)
  
- After setting up your PCL development environment, clone the sources in src/modules/processes/Python/

- Regenerate the Makefiles/projects using the PixInsight Makefile generator settings shown in makefileGenerator.JPG,
  or edit the provided Makefiles/projects to have suitable paths. If you find an entry like "-lboost_python.lib",
  change it into "-lboost_python" (this is a bug in the MakefileGenerator of PI1.7)

- Try to build. You may need to install additional modules from your Linux distributions repository. For instance, on
  Fedora 17 I install "python-devel", "boost-devel" (development headers for those tools) using "Add/Remove Software"

- On Fedora 17, you also may need to install an older version of GCC (version 4.7.2 appears to be incompatible with
  the latest PCL libary). I am using gcc 4.6.3.

- For running the examples, you may also need to install pyephem, python-matplotlib, numpy and scipy.

The source is organized as follows:

- PythonInterface.cpp, PythonParameters.cpp, PythonInterface.h, PythonParameters.h, PythonModule.cpp, PythonProcess.cpp,
  PythonModule.h, PythonProcess.h contain the usual boilerplate code to define the module, gui, parameters. Nothing
  very exciting there.

- PythonInstance.cpp/PythonInstance.h contain the engine that drives the Python interpreter. It is using Boost::Python
  to control the interpreter (which in turn is a thin interface on what is usually done using the Python-CAPI defined
  in Python.h)

- The language mapping is defined in PythonBindings.cpp/PythonBindings.h. This is very the really complicated stuff happens.
  Boost::Python does a lot of work behind the scenes, such as most of the conversions and refCounting.
  In many cases, mapping methods and objects is pretty straight forward, but things can also get fairly involved. 
  PythonBindings.cpp contains some pointers to literature. I would recommend the tutorial in 
  http://www.boost.org/doc/libs/1_5w_0/libs/python/doc/ as a starting point.
  
The Language Mapping Philosophy
-------------------------------

Here the general ideas that I followed when implementing the language bindings. I do not claim that they are the final
wisdom, and you are welcome to comment:

- map to native Python types where possible, e.g. pcl::Array->list and pcl::String->str

- using consistent Python naming conventions, i.e. lower case for modules (pixinsight),
  CamelWrite with upper case first letter for classes, lower case letters with _ separators
  as method names.

- Use Pythons weak typing. We dont have several GenericImage<> classes in Python, just one Image.

- Do not map everything you find in PCL to Python. Many PCL methods are redundant, or are unlikely to be used in scripts

- still, stay close to PCL (not like the PJSR solution that introduces many new/simplified objects). The idea is to
  stay close to PCL so it may be possible in future to implement PI-Processes in PI without the restrictions of
  PJSR

- do not map GUI elements (yet) - use Python GUI instead. This may change in future...

  
Development: What needs to be done?
-----------------------------------

Obviously, there is still a lot to be done. Here is a list with a preliminary estimate of the difficulty 
(H=high, M=medium, L=low). I am afraid most tasks need a lot of stamina...

- M: Examine and solve problem with Image.get_luminance()

- M: Investigate crashes when using IDLE

- complete Language mapping for ImageWindow, View, Image/ImageVariant. 
  - M: It should be possible to create/delete instance of these from Python
  - L: Image processing/manipulation Ops on Image. Should be simple with PCL2.0, where much of this is available on ImageVariant
  - L: Transfer of whole images from Python to PCL (set_image_as_list())

- M: Implement option to call other PCL processes (PCL2.0)

- H: Design way to define PI processes in Python. I currently dont see fundamental obstacles to this.

- M: Make PCL GUI available. I am currently not sure if we should to this.

- H: Find out how to properly reset Python with Boost::Python. Boost::Python currently does not support Py_Finalize().

- H: Run Python out-of-process, sending the PCL calls as RPCs. This should resolve the issues with Py_Finalize() and
     especially avoid possible library incompatibilities between PixInsight and Python (as already seen with Qt), and
     to avoid difficulties with unloading libraries. For instance IDLE already does this (if not started with -n), 
     probably for similar reasons.
     
-M: Go through the FIXMEs in the source code.

- L: Test, Tests, Tests

- ...
 
