Directory for new PCL processes
