This is a repository for development of PixInsight (www.pixinsight.com) modules and scripts. You are welcome to contribute. Contact me on georg.viehoever@web.de.
Georg
